/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sorriso.classes;

/**
 *
 * @author nicoe
 */
public class Doencas {
    private int id_doenca;
    private String nome_doenca;
    private String sintomas;
    private String descritivo_doenca;

    public int getId_doenca() {
        return id_doenca;
    }

    public void setId_doenca(int id_doenca) {
        this.id_doenca = id_doenca;
    }

    public String getNome_doenca() {
        return nome_doenca;
    }

    public void setNome_doenca(String nome_doenca) {
        this.nome_doenca = nome_doenca;
    }

    public String getSintomas() {
        return sintomas;
    }

    public void setSintomas(String sintomas) {
        this.sintomas = sintomas;
    }

    public String getDescritivo_doenca() {
        return descritivo_doenca;
    }

    public void setDescritivo_doenca(String descritivo_doenca) {
        this.descritivo_doenca = descritivo_doenca;
    }
}
