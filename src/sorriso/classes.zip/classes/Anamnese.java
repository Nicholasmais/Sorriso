/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sorriso.classes;

/**
 *
 * @author nicoe
 */
public class Anamnese {
    private int id_anamnese;
    private String nome_cliente;
    private String nome_dentista;

    public int getId_anamnese() {
        return id_anamnese;
    }

    public void setId_anamnese(int id_anamnese) {
        this.id_anamnese = id_anamnese;
    }

    public String getNome_cliente() {
        return nome_cliente;
    }

    public void setNome_cliente(String nome_cliente) {
        this.nome_cliente = nome_cliente;
    }

    public String getNome_dentista() {
        return nome_dentista;
    }

    public void setNome_dentista(String nome_dentista) {
        this.nome_dentista = nome_dentista;
    }
}
